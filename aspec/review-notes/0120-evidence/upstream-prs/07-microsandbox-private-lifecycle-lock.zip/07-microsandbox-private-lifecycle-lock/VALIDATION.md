# Focused lifecycle validation

Executed 2026-11-19 on `aarch64-unknown-linux-gnu`, Rust 1.95.0
(`59807616e1fa2540724bfbac14d7976d7e4a3860`). The checkout was based on
`abff71505fc46416b3d704ee2787f8e55ae66efa` and had the reconciled saved proposals
applied. No upstream branches, commits or submissions were created.

Both commands passed with three tests, zero failures and zero ignored tests:

```sh
(umask 0002; CARGO_TARGET_DIR=/tmp/awman-upstream-review/check-target cargo +1.95.0 test --locked -p microsandbox-runtime --lib client::ipc::tests::lifecycle_guard_ -- --nocapture)
(umask 0077; CARGO_TARGET_DIR=/tmp/awman-upstream-review/check-target cargo +1.95.0 test --locked -p microsandbox-runtime --lib client::ipc::tests::lifecycle_guard_ -- --nocapture)
```

The executed tests were:

- `client::ipc::tests::lifecycle_guard_is_exclusive_and_reusable`
- `client::ipc::tests::lifecycle_guard_remains_owned_by_an_inherited_descriptor`
- `client::ipc::tests::lifecycle_guard_waits_for_release_and_reports_timeout_separately_from_io_errors`

| Input or evidence | SHA-256 |
|---|---|
| `07-microsandbox-private-lifecycle-lock.diff` | `e146db59b9757863141b4313234bc0cae324c8c76da5d78dab50e3d0a7b8027f` |
| Patched `crates/runtime/lib/client/ipc.rs` | `d97806e7ac31d1bce2fb77e90e6660f35ba545ae6eabd5e111b99b85274c3954` |
| Upstream `Cargo.lock` | `316e261f26161b66a749573b314fa7d8f6fddee96aa29bd5c2943cc14c0f63c2` |
| `lifecycle-umask0002.log` | `b79172e078f22232127db4b08aba4cf6e665a11c47da1ba7031b2e54d60ab0a3` |
| `lifecycle-umask0077.log` | `e7ccad7d0f05734b7bbeb23cce13cde9e18968f830512dbd42deadc34f4f95d2` |
| Runtime test executable | `5fc45f6410b565db3491288984dfff6733b6654dcf0dcb16a99ccceebbf0f399` |

This validates the upstream lifecycle-lock change and descriptor lifetime; it
does not establish Linux x86_64 or macOS native guest acceptance, test all
upstream runtime behavior, or justify removing awman's carried patch.
