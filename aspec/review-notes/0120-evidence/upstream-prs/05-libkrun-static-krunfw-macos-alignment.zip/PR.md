**Title:** `docs(krun): note Mach-O static alignment limit and add heap-backed kernel example`

**Repository:** `superradcompany/libkrun` · **Base:** `krun` (default branch) @ `cd5181964b62ff23654061f814e519efda731378` · **Branch suggestion:** `docs/static-krunfw-macos-alignment`

---

Closes #<issue-05-number>

## Summary

The `static-krunfw` crate docs recommend `#[repr(align(65536))]` on a `static mut` to get the 64 KiB-aligned, writable kernel image the VMM requires. On macOS that isn't reliable. Mach-O caps section alignment below 64 KiB, so the `static` can land on a smaller boundary, and the VMM can then refuse the image.

We hit this embedding libkrun (via Microsandbox) on Apple Silicon. We switched to a leaked, 64 KiB-aligned heap copy made once at startup, which works on every target we've tried.

## Changes

This is documentation only, in `src/krun/src/lib.rs` crate docs, with no API or behaviour change. Under "Alignment and writability":
- adds a paragraph explaining that `repr(align)` on a `static` is a linker request that Mach-O doesn't honour at 64 KiB;
- adds a "Heap-backed images" subsection with a portable `krunfw_get_kernel` example:
  - It copies the image once, behind a `OnceLock`, into a `std::alloc::alloc_zeroed` allocation with a 64 KiB `Layout`.
  - The allocation is never freed, so it satisfies "Kernel memory lifetime".
  - The image length must be a multiple of 64 KiB, as libkrunfw's bundles are.

## Test plan

- [x] I extracted the new example and compiled it standalone with `rustc --edition 2021 -D warnings`. A small `main` then called `krunfw_get_kernel` and checked three things:
  - the returned pointer is 64 KiB-aligned;
  - `*size` equals the image length;
  - the buffer is writable.
- [x] `cargo test --doc -p msb_krun --features static-krunfw`: all doctests pass (24 passed, 6 ignored), including the new example. It is `no_run`, like its neighbours, so the doctest compiles it without running it.

## Not included

The issue also suggested a note on the `com.apple.security.hypervisor` entitlement for macOS binaries that boot a VM. It isn't specific to `static-krunfw`, so I've left it out to keep this PR to one change. I'm happy to send it separately if you want it.

🤖 Generated with [Claude Code](https://claude.com/claude-code)
