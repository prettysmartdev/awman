> Reconciled 2026-11-19. Saved proposal only; not submitted. Patch application and whitespace were checked against the exact base below. Full upstream compilation, native tests and maintainer review are still required before submission. This is not evidence for removing the awman 0.7.8 patch.

# Private memory for fresh x86_64 guests

**Repository:** `superradcompany/microsandbox`

An embedded kernel accessor is process-owned and can be reused by several VMs. Fresh Linux x86_64 guests must call the existing libkrun `Vm::set_private_memory_boot(true)` before entry, so each guest writes private RAM. Checkpoint restores continue to install their own independently owned memory.

Removal gate: a pinned published runtime that applies equivalent fresh-boot isolation, the exact libkrun private-memory sibling/backing tests, concurrent native guests, and stripped/LTO artifact boots. No libkrun fork is needed.

**Base:** `main` @ `abff71505fc46416b3d704ee2787f8e55ae66efa` (0.7.16).

## Review and remaining acceptance

The current libkrun base still exposes `Vm::set_private_memory_boot(bool)` in `src/krun/src/api/vm.rs`. The rebased Microsandbox SDK/runtime/CLI compile with `cargo +1.95.0 check --locked -p microsandbox-cli --no-default-features --features net` on Linux aarch64; that host does not compile the x86_64-only call or establish native boot evidence.

This changes every fresh Linux x86_64 boot to the existing private sparse-file memory path, not only static-kernel embedders. Before submission, review host temporary-storage permissions/capacity, memory-placement compatibility and performance, and run native fresh-boot, concurrent-guest and restore regressions against this exact upstream base. No wire or persisted guest-storage format changes are proposed.
