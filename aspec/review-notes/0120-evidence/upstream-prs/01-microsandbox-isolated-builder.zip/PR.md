**Title:** `feat(sdk): add LocalBackendBuilder::build_lazy_isolated`

**Repository:** `superradcompany/microsandbox` · **Base:** `main` @ `4f5ea5cfd75c6953ccac388926fba8225c3411dc` · **Branch suggestion:** `feat/sdk-isolated-local-builder`

---

Closes #<issue-01-number>

## Summary

Adds `LocalBackendBuilder::build_lazy_isolated()`. It builds a lazy `LocalBackend` from built-in defaults and the builder's own settings, and never reads either config file:
- the user config file (`config_path`, `MSB_CONFIG_PATH` or `~/.microsandbox/config.json`);
- the machine-wide managed configuration.

Otherwise it matches `build_lazy()`. The builder's overrides still go through `prepare_for_local_backend`, and `require_backend(BackendKind::Local, None)` still runs, so validation is unchanged.

This lets an application that embeds the SDK and configures it entirely in code stay unaffected by a user's or administrator's standalone Microsandbox config. That includes a malformed config, which currently makes `build_lazy()` fail.

## Changes

- `sdk/rust/lib/backend/local/mod.rs`
  - Adds `build_lazy_isolated()`. It passes `GlobalConfig::default()` and an empty managed layer to `BackendConfig::new(...)` in place of `BackendConfig::load_from(...)`.
  - Adds the test `build_lazy_isolated_ignores_user_and_managed_config_files`.

The change is additive: no existing method changes behaviour. The SDK-registered runtime paths and the `MSB_PATH`/`MSB_LIBKRUNFW_PATH`/`MSB_AGENTD_PATH` overrides are still layered, as the doc comment says. An embedder that must also ignore those variables can refuse them before calling this method.

## Compatibility

There is no wire, persisted-state or SDK↔`msb` boundary change. The new method only chooses which config layers feed the existing `BackendConfig` path, and existing callers are unaffected.

## Test plan

- [x] `cargo test -p microsandbox --lib build_lazy`. The new test:
  - writes an invalid managed config and checks that `build_lazy()` errors while `build_lazy_isolated()` succeeds;
  - repeats the check with an invalid user config.
- [x] `cargo clippy -p microsandbox -- -D warnings`, matching CI. With `--all-targets` there are pre-existing lint errors on `main` in test code, none in the lines this PR touches.
- [x] `cargo fmt --all --check`
- Run on Linux aarch64. We have carried the same method as a patch on `microsandbox 0.7.8`, and it ships in awman's macOS arm64 builds.

## Open questions (from the issue)

- Would you prefer this as a builder flag, for example `.ignore_config_files(true)`?
- Should there be an async `build_isolated()` that opens the database, mirroring `build()`?

🤖 Generated with [Claude Code](https://claude.com/claude-code)
