> Reconciled 2026-11-19. Saved proposal only; not submitted. Patch application and whitespace were checked against the exact base below. Full upstream compilation, native tests and maintainer review are still required before submission. This is not evidence for removing the awman 0.7.8 patch.

**Title:** `feat(sdk): add LocalContextBuilder::build_isolated`

**Repository:** `superradcompany/microsandbox` · **Base:** `main` @ `abff71505fc46416b3d704ee2787f8e55ae66efa` · **Branch suggestion:** `feat/sdk-isolated-local-builder`

---

Closes #<issue-01-number>

## Summary

Adds `LocalContextBuilder::build_isolated()`. It builds a lazy `LocalContext` from built-in defaults and the builder's own settings, and never reads either config file:
- the user config file (`config_path`, `MSB_CONFIG_PATH` or `~/.microsandbox/config.json`);
- the machine-wide managed configuration.

Otherwise it matches `build()`. The builder's overrides still go through `prepare_for_local_backend`, and `require_backend(ContextKind::Local, None)` still runs, so validation is unchanged.

This lets an application that embeds the SDK and configures it entirely in code stay unaffected by a user's or administrator's standalone Microsandbox config. That includes a malformed config, which currently makes `build()` fail.

## Changes

- `sdk/rust/lib/context/local/mod.rs`
  - Adds `build_isolated()`. It passes `GlobalConfig::default()` and an empty managed layer to `BackendConfig::new(...)` in place of `BackendConfig::load_from(...)`.
  - Adds the test `build_isolated_ignores_user_and_managed_config_files`.

The change is additive: no existing method changes behaviour. The SDK-registered runtime paths and the `MSB_PATH`/`MSB_LIBKRUNFW_PATH`/`MSB_AGENTD_PATH` overrides are still layered, as the doc comment says. An embedder that must also ignore those variables can refuse them before calling this method.

## Compatibility

There is no wire, persisted-state or SDK↔`msb` boundary change. The new method only chooses which config layers feed the existing `BackendConfig` path, and existing callers are unaffected.

## Test plan

- [ ] `cargo test -p microsandbox --lib build_isolated`. The new test:
  - writes an invalid managed config and checks that `build()` errors while `build_isolated()` succeeds;
  - repeats the check with an invalid user config.
- [ ] `cargo clippy -p microsandbox -- -D warnings`, matching CI. With `--all-targets` there are pre-existing lint errors on `main` in test code, none in the lines this PR touches.
- [ ] `cargo fmt --all --check`
- Run on Linux aarch64. We have carried the same method as a patch on `microsandbox 0.7.8`, and it ships in awman's macOS arm64 builds.

## Open questions (from the issue)

- Would you prefer this as a builder flag, for example `.ignore_config_files(true)`?


## Rebase validation (2026-11-19)

`cargo +1.95.0 check --locked -p microsandbox-cli --no-default-features --features net` passed on Linux aarch64, compiling this SDK addition. `cargo +1.95.0 fmt --all -- --check` and `git diff --check` passed. The new builder regression test and default-feature builds still require execution before submission.
