> Reconciled 2026-11-19. Saved proposal only; not submitted. Patch application and whitespace were checked against the exact base below. Full upstream compilation, native tests and maintainer review are still required before submission. This is not evidence for removing the awman 0.7.8 patch.

**Title:** `feat(network): add opt-in strict_sni for end-to-end TLS under strict mode`

**Repository:** `superradcompany/microsandbox` · **Base:** `main` @ `abff71505fc46416b3d704ee2787f8e55ae66efa` · **Branch suggestion:** `feat/network-strict-sni`

---

Closes #<issue-03-number> · Related: #<issue-04-number>

## Summary

This adds a default-off network option, `strict_sni`. With `strict(true).strict_sni(true)`, a TLS connection allowed only by a hostname rule is admitted end to end, without interception. That requires both of these:
- its visible ClientHello SNI matches an allow rule;
- the policy's DNS-binding check for that SNI passes.

Everything strict mode can't verify is still refused.

| Connection (strict + strict_sni) | Result |
|---|---|
| Allowed visible SNI with a DNS binding to the dialed IP | Allowed, end to end |
| No SNI, including ECH-only ClientHellos | Refused |
| SNI not in the allow list | Refused |
| Allowed SNI with no DNS binding to the dialed IP | Refused |

The boundary is only what's visible. The encrypted HTTP `Host`/`:authority`, domain fronting behind an allowed server, and ECH's inner name aren't inspected, and QUIC isn't covered. All of this is documented on the option.

## Changes

- **`microsandbox-network`**
  - `NetworkConfig.strict_sni` is `#[serde(default)]` and is omitted when false. Adds `NetworkBuilder::strict_sni(bool)`.
  - The flag is threaded through `SmoltcpNetwork` and `smoltcp_poll_loop` to `TcpProxy::with_strict_sni`.
  - In `TcpProxy`, the opaque-TLS strict refusal is skipped only when `strict_sni` is on and an SNI is present. Policy evaluation has already required the DNS binding for that SNI.
- **`microsandbox-types`**
  - `NetworkSpec.strict_sni` is defaulted and omitted when false, so it survives the SDK's `NetworkConfig` ↔ `NetworkSpec` round trip.
  - The cloud → `NetworkSpec` conversion sets it to `false` explicitly.
- **Runtime/CLI:** `LaunchCapabilities` gains `strict_sni`. `msb __launch-protocol` advertises it on `net` builds.
- **Rust SDK**
  - `machine` launches with `strict_sni` probe for the capability, and refuse with "upgrade msb" when it's missing.
  - v0.6.x launch contracts refuse it before launch.
  - Managed cloud refuses it before HTTP, as `unsupported("network.strict_sni")`, because the cloud create contract doesn't carry it.
- **Docs:**
  - adds `network.strict_sni()` to `docs/sdk/rust/networking.mdx`;
  - adds a `COMPATIBILITY.md` entry next to the other optional network keys.

## Compatibility review (per AGENTS.md)

- **Default behaviour is unchanged.** The key is omitted when false, so launches, persisted configs and generated bindings that don't set it are byte-identical.
- **New SDK → older `msb` (`machine`).** These runtimes decode network JSON leniently and would drop the key, which would refuse TLS the caller asked to admit. The SDK probes `__launch-protocol` only when the key is set, and returns an upgrade-required error if the capability is missing. This follows the `tcp_accept_queue_size` precedent.
- **New SDK → v0.6.x `msb`.** Refused in `validate_network` before launch, for every patch from 0 to 18.
- **Older SDK → new `msb`.** It never sends the key, so nothing changes.
- **Older SDK restarting a sandbox persisted with `strict_sni: true`.** The old `NetworkSpec` ignores the unknown key and falls back to ordinary strict mode. That loses functionality (non-intercepted HTTPS is refused again) but never admits traffic the old release would refuse. I haven't added a downgrade guard for this, and I'd welcome direction if you want one.
- **Cloud.** Refused client-side, so it is never silently dropped by the server.

## Scope note

This exposes the option in the Rust SDK only. AGENTS.md asks for the CLI and the Python, Node and Go SDKs to stay consistent. I've held those back until you've agreed on the shape (a separate flag here, or a `strict` mode such as `strict = "sni"`), and I'll add them in this PR or a follow-up, whichever you prefer.

## Test plan

Re-run these checks against the base commit above before submission. Previous checked results were from the older proposal base and do not validate this rebase:

- [ ] `cargo test -p microsandbox-network --lib`: all tests pass, including the new ones:
  - `strict_sni_end_to_end_tls_reaches_allowed_server_without_interception`: a real Rustls handshake and data exchange through `TcpProxy` to a local allowed server, with no interception.
  - `strict_sni_denies_missing_wrong_and_unbound_names_before_dial`: a missing SNI, an unlisted SNI on a shared IP and an SNI with no DNS binding are each `PolicyDenied`, and the local listener is never dialled.
  - `strict_sni_is_explicit_and_survives_config_roundtrip`: off by default for old configs; survives builder → JSON → `NetworkConfig`.
  - `strict_sni_round_trips_through_network_spec`: survives `NetworkConfig` → `NetworkSpec` → `NetworkConfig`, and is omitted from both wire types when unset.
  - The existing strict-mode deny tests are unchanged and pass.
- [ ] `cargo test -p microsandbox-types`
- [ ] `cargo run -p microsandbox-types --features ts --bin microsandbox-types-generate -- --check`, which confirms the generated bindings are unchanged.
- [ ] `cargo test -p microsandbox --lib` filtered to `strict_sni`, `launch_contract` and `cloud_create_request`:
  - `strict_sni_requires_advertised_support`: an unset key never probes, an old runtime gets "upgrade msb", and an advertising runtime passes.
  - `legacy_runtimes_reject_strict_sni`: v0.6.x patches 0 to 18 refuse; `machine` accepts.
  - `cloud_create_request_rejects_strict_sni`.
- [ ] `cargo build -p microsandbox-cli`
- [ ] `cargo clippy -p microsandbox-network -p microsandbox-types -p microsandbox -p microsandbox-runtime -p microsandbox-cli -- -D warnings`, matching CI. `--all-targets` is also clean for `microsandbox-network` and `microsandbox-types`. For the SDK and runtime, `--all-targets` hits lint errors that already exist on `main`, in test code this PR does not touch.
- [ ] `cargo fmt --all --check`

We have also carried this behaviour as a patch on 0.7.8 and run it in real guests on Apple Silicon. Those tests cover:
- allowed HTTPS through an allow list;
- denied egress (DNS, direct IP and proxy bypass);
- policy isolation between concurrent VMs.

## Related

The sibling-binding case for suffix rules is in #<issue-04-number> and its separate PR. This PR doesn't depend on that one, and works with either outcome.


## Rebase validation (2026-11-19)

On Linux aarch64 with Rust 1.95.0 and the committed upstream lockfile:

- `cargo +1.95.0 check --locked -p microsandbox-network --tests` passed.
- `cargo +1.95.0 test --locked -p microsandbox-network --lib strict_sni` passed all four selected tests.
- `cargo +1.95.0 test --locked -p microsandbox-network --lib hostname_source_sni_domain_suffix` passed both selected tests.
- `cargo +1.95.0 check --locked -p microsandbox-cli --no-default-features --features net` passed, including the SDK and runtime.

The checks used isolated build directories. Rust 1.94.0 cannot build this upstream lockfile because its parking_lot dependencies require 1.95. These targeted checks do not establish default-feature, cross-version, other-language SDK or native guest acceptance.

`cargo +1.95.0 fmt --all -- --check` and `git diff --check` also passed for the combined rebased proposals.

## Required policy dependency

The exact-name DNS binding guarantee requires proposal 04 (or an upstream equivalent). Current upstream intentionally permits sibling bindings for DomainSuffix rules. Do not ship this option with a claim of exact SNI/IP binding while that policy remains unchanged. The focused tests here cover exact Domain rules; acceptance must also run the suffix-binding tests with both proposals applied.
