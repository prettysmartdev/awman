**Title:** `feat(filesystem): add MSB_EMBED_ARTIFACTS_ROOT for per-arch agentd`

**Repository:** `superradcompany/microsandbox` · **Base:** `main` @ `4f5ea5cfd75c6953ccac388926fba8225c3411dc` · **Branch suggestion:** `feat/filesystem-embed-artifacts-root`

---

Closes #<issue-02-number>

## Summary

With `embed-binaries`, the `microsandbox-filesystem` build script takes Agentd from `MSB_EMBED_ARTIFACTS_DIR/agentd`, which is one directory for every target. This PR adds an optional, target-aware alternative:

```
MSB_EMBED_ARTIFACTS_ROOT/<CARGO_CFG_TARGET_ARCH>/agentd
```

Because the build script picks the file, one build environment can supply the right Agentd for several targets. That includes a static `.cargo/config.toml` `[env]` entry, which can't vary per target. The chosen file still goes through `validate_agentd_file`.

## Changes

- **`crates/filesystem/build.rs`**
  - Registers `rerun-if-env-changed=MSB_EMBED_ARTIFACTS_ROOT`.
  - When the variable is set, it stages `<root>/<target_arch>/agentd` before the existing `MSB_EMBED_ARTIFACTS_DIR` branch.
  - If the file for the target is missing, the build panics instead of falling back, so a missing architecture is never silently replaced by another source.
- **`DEVELOPMENT.md`:** documents the variable in "Selecting Embedded Binaries".

When the variable is unset, `MSB_EMBED_ARTIFACTS_DIR`, the workspace `build/` copy and the `download-binaries` path behave exactly as before. The variable only selects Agentd. `msb` and `libkrunfw` selection in `sdk/rust/build.rs` is untouched.

## Compatibility

This is a build-time input only. Nothing changes at runtime, on the wire or in persisted state, and builds that don't set the variable are unaffected.

## Test plan

Build-script behaviour was checked by hand on Linux aarch64 (`CARGO_CFG_TARGET_ARCH=aarch64`):

- [x] Root set, with `<root>/aarch64/agentd` present: `cargo build -p microsandbox-filesystem` succeeds, and the build log shows the file staged from the root.
- [x] Root set, with no `aarch64/agentd` under it: the build fails with `MSB_EMBED_ARTIFACTS_ROOT does not contain aarch64/agentd: …`.
- [x] Root unset: `cargo build -p microsandbox-filesystem` succeeds through the existing path.
- [x] `cargo fmt --all --check`

There is no automated test, because build scripts here have no harness. I'm happy to add a CI step that sets the variable, if you'd like one.

We have carried the same branch as a patch on `microsandbox-filesystem 0.7.8`. Every embedded build we ship stages Agentd through it, and we check the staged bytes against pinned hashes.

## Open questions (from the issue)

- Key by `CARGO_CFG_TARGET_ARCH`, as here, or by the full target triple?
- If both variables are set, should the root win, as here, or should that be an error?

🤖 Generated with [Claude Code](https://claude.com/claude-code)
