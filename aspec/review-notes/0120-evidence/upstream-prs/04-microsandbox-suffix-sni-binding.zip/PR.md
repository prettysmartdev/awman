> Reconciled 2026-11-19. Saved proposal only; not submitted. Patch application and whitespace were checked against the exact base below. Full upstream compilation, native tests and maintainer review are still required before submission. This is not evidence for removing the awman 0.7.8 patch.

**Title:** `fix(network): require exact DNS binding for SNI under DomainSuffix allows`

**Repository:** `superradcompany/microsandbox` · **Base:** `main` @ `abff71505fc46416b3d704ee2787f8e55ae66efa` · **Branch suggestion:** `fix/network-suffix-sni-exact-binding`

---

Closes #<issue-04-number> · Related: #<issue-03-number>

> **Behaviour change.** This implements option 1 from the issue (tighten in every mode). Please don't merge until the issue settles which option you want. If you choose option 2 (tighten only under `strict_sni`), I'll rework this on top of the strict_sni PR.

## Summary

For a `DomainSuffix` allow rule with an SNI hostname source, policy currently admits a connection when:
- the SNI matches the suffix, and
- the dialled IP was resolved for **any** name under the suffix.

Inside an allowed suffix, the guest picks both the SNI and the IP. It can resolve `a.example.com` and then claim `b.example.com` against that IP, even though `b.example.com` never resolved there. An exact `Domain` rule already requires the binding for that exact name.

This PR makes suffix allows require a DNS binding for the SNI name itself:

```rust
let cache_matches = || shared.any_resolved_hostname(addr, |hostname| hostname == name);
```

Deny rules still match on the SNI alone. `CacheOnly` and `Deferred` sources are unchanged.

## Changes

- `crates/network/lib/model/policy/types.rs`:
  - changes the cache check in the `DomainSuffix` / `HostnameSource::Sni` arm of `matches_egress_destination_with_source`;
  - renames `hostname_source_sni_domain_suffix_allows_sibling_cache_binding` to `…_denies_sibling_cache_binding`, and it now asserts `Deny`;
  - updates the doc comment on the exact-binding allow test;
  - adds `hostname_source_sni_domain_suffix_deny_ignores_cache_binding`.

## Compatibility review (per AGENTS.md)

- **What changes, and for whom.** This is evaluated in the runtime, so it applies to every sandbox started by an `msb` with this change, whichever SDK launched it.
- **Failure mode.** A guest that connects with an SNI it never resolved, to an IP resolved for a sibling name under the same allowed suffix, is now refused. The removed test describes that pattern as the "Real shared-CDN case" (`other.pythonhosted.org` serving `files.pythonhosted.org`). Clients that resolve the name they connect to keep working.
- **Not affected:**
  - running sandboxes on an older `msb`;
  - persisted configuration;
  - the wire format;
  - exact `Domain` rules;
  - deny rules;
  - non-SNI sources.
- **Options, if you'd rather not change the default:**
  - gate this on the opt-in `strict_sni` (option 2 in the issue);
  - or add a separate per-policy switch.

## Test plan

Re-run these checks against the base commit above before submission. Previous checked results were from the older proposal base and do not validate this rebase:

- [ ] `cargo test -p microsandbox-network --lib`: all tests pass.
  - `hostname_source_sni_domain_suffix_denies_sibling_cache_binding`: a sibling binding alone no longer authorizes the SNI.
  - `hostname_source_sni_matches_domain_suffix_with_cache_binding`: still allowed with the exact binding.
  - `hostname_source_sni_denies_domain_suffix_without_cache_binding`: still denied.
  - `hostname_source_sni_domain_suffix_deny_ignores_cache_binding`: a deny suffix rule still matches on SNI alone.
- [ ] `cargo clippy -p microsandbox-network --all-targets -- -D warnings`
- [ ] `cargo fmt --all --check`

In practice, legitimate clients resolve the name they connect to. We have carried this exact change on `microsandbox-network 0.7.8` in every mode and haven't seen it break CDN-hosted registries, though our usage is narrow.


## Rebase validation (2026-11-19)

On Linux aarch64 with Rust 1.95.0 and the committed upstream lockfile:

- `cargo +1.95.0 check --locked -p microsandbox-network --tests` passed.
- `cargo +1.95.0 test --locked -p microsandbox-network --lib strict_sni` passed all four selected tests.
- `cargo +1.95.0 test --locked -p microsandbox-network --lib hostname_source_sni_domain_suffix` passed both selected tests.
- `cargo +1.95.0 check --locked -p microsandbox-cli --no-default-features --features net` passed, including the SDK and runtime.

The checks used isolated build directories. Rust 1.94.0 cannot build this upstream lockfile because its parking_lot dependencies require 1.95. These targeted checks do not establish default-feature, cross-version, other-language SDK or native guest acceptance.

`cargo +1.95.0 fmt --all -- --check` and `git diff --check` also passed for the combined rebased proposals.
